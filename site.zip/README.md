# What Next?

**Version 3.0.0** · Company: Tokyo Brotherhood · Creator: Hariharasuthan Karunakaran · Contributor: Claude (AI)

An Android app that picks what to watch or read next from your [AniList](https://anilist.co), based on how much time you have.

The app is plain HTML, CSS and JavaScript inside an Android shell ([Capacitor](https://capacitorjs.com)): a thin `index.html` loads the rest of the files, and the included GitHub workflow builds the APK. There is no website version.

Notifications show the app's own small icon (the logo's play-next symbol in a ring) in the status bar next to the clock, tinted purple in the notification shade (`native/android-res/drawable/ic_stat_whatnext.xml`; Android draws only the shape of a status-bar icon, so it cannot be the colourful logo). A bell at the top (next to your name) opens **Notifications**, and **Settings > Notifications** has the notification switches. There are six tabs along the bottom: **Pick**, **Anime**, **Manga**, **Discover**, **Schedule**, and **Profile** (Stats, Chat, and Settings live inside Profile).

## Features

- **Pick for me:** choose Watch, Read, or Either, then how much time you have (15 min, 30 min, 1 hour, 2 hours). It suggests something from your Watching, Reading, Repeating, and Planning lists that fits, and tells you which episodes or chapters to do. Titles that are not released yet are never suggested, and for a show that is still airing it only offers episodes that have already aired.
- **Pick Memory (hybrid):** Pick now learns what you like. Under each pick are **Why this pick** chips (what it learned about you first, then your list, your time and the score, at most three) and three reactions: **Great pick** (learns a like; says what it learned and offers *Undo*), **Not for me** (learns a dislike and shows the next one) and **Not today** (sets the title aside until tomorrow and learns nothing). It learns small weights for genres, length (short, mid, long), decade and country of origin, separately for anime and manga, and adds a **capped bonus of at most 25 points** to Pick's own score (about 100 to 180), so it nudges the order and never hides or invents anything. A trait needs about 3 reactions before it counts in full; a learned preference loses half its strength in 90 days without new reactions; a genre you chose as the filter is not learned from; and about 1 pick in 7 is a deliberate **change of pace** so you are not stuck in one taste. There is no cold start: the first time you use Pick it reads your own list once in the background (high scores lift a trait, low scores and dropped titles lower it, measured against your own average). *Surprise me* stays purely random. The settings are in **App Settings > Pick Memory**: *Use Pick Memory*, *Keep learning from my reactions*, a summary of what it learned from, and *Reset what it learned* (two taps; it then starts again from your list). Everything is kept on the phone (`wn_pickmem`, `wn_pm_snooze`), removed at sign-out, and no request is made except reading your list once. The maths is in `js/features/pickmem-math.js` (tested in `tests/unit/pickmem.test.js`, screens in `tests/e2e/pickmem.e2e.py`). Still to come (the next steps of the plan): a Memory page with the learned bars and Favour / Mute for each trait (the maths for your own settings already works), learning from Mark as done, Add to Planning, Hide and Another, and formats and themes.
- **Something new for my taste:** a button under Surprise me and Build a lineup. It picks an anime or manga that suits your taste report (your top genres and strongest themes) and is **not on any of your lists**; AniList filters out everything you already have, and unreleased titles are skipped. It follows the Watch/Read, time, genre and 18+ filters, with Another, Hide, and Add to Planning.
- **Genre filter:** the genre chips are built from what's actually in your list.
- **18+ filter:** show everything, only 18+ titles, or hide 18+ titles.
- **Discover tab:** one search box that searches by itself as you type (no Find button). Pick what to search with the chips: Anime, Manga, Characters, Staff, Studios, or Users. With the box empty, the same list is **Explore**: a ranked list for that type (popularity for titles, favourites for people). The filter button has every option: sort, genres, tags, year, season, format, status, country, source, on or off your list, and 18+ (hidden by default). Four tiles sit under the search box:
  - **Seasonal:** the seasonal chart for any year and season, grouped by format, with sort and order, and Hide or Only series on your list.
  - **Calendar:** a month grid of posters (up to four a day, then +N), like a TV guide. Tap a day for the week list: a day strip, then cards with the air time, title, episode and your list status. A tick button marks an aired episode as watched when it is the next one you can watch. Chips filter to Premieres (episode 1) or Finales; the filter button limits to your Watching and Planning list, the current season, or shows adult content. Tap the month to jump, the date button for today, and the grid button to switch views.
  - **For you:** trending titles in your favourite genres that are not on your list.
  - **Rediscover:** your paused and dropped titles, best rated first.
  Titles on your list show their real status, and + Planning only appears for titles that are not on your list.
- **Taste report:** a card on your **Profile** (under the counts) opens your taste report, for anime or manga. It compares your list with the most popular titles on AniList (the "average fan") and shows: an **archetype** from your strongest theme (for example *The Portal Hopper* for Isekai), a **theme index** of what you like far more or far less than the average fan, a four-letter **personality type** from four sliders (Niche or Mainstream, Retro or Fresh, Diverse or Specialized, Contrarian or Aligned) with hidden gems, newer or older picks, a genre mix and your biggest rating gaps with other fans, five **vibe** sliders (Grim or Wholesome, Heart or Brain, Dreamers or Schemers, Scrappy or Destined, Competitive or Loyal), a **one-line summary** with a **confidence level** (High, Medium or Low, from how many titles and ratings it has), the **runner-up archetype**, and a Share button. The Contrarian slider needs at least 8 rated titles, and the report needs at least 8 started or finished titles. Adult titles count in the maths but never show as covers. The sample of popular titles is kept on your device for a week. The page opens with your archetype in a gradient card and a strip showing how many titles it used, then your four-letter type as four tiles, and each slider fills from the middle towards your side with a lean percentage.
  - **Smarter reading of your list** (`js/features/taste-insights.js`, tested in `tests/unit/taste-extra.test.js`): **What your list says** gives plain sentences, each only when the list supports it: whether you rate above or below other fans on the same titles (Generous, Balanced or Tough), whether you finish or sample, the genre you drop far more than usual, your best-rated and toughest genre against your own average, how your taste has **moved lately** (the last two years against everything before: fresher, more niche, more specialized, and a rising theme), whether you keep up with new releases or love older ones, your decade, typical length (episodes or chapters), your most-watched studio and what your anime are based on. **How you rate** shows how you use the 1 to 10 scale as a bar chart, with average, median and your gap to the fans. **Eras and formats** and **Studios** show where your titles come from. **Try next** lists titles that match your taste and are on none of your lists (the same engine as Something new for my taste). Nothing is said about a genre or studio with fewer than 3 or 4 titles, and the rater and finisher lines need 8 rated or 6 finished or dropped titles.
  - **Share as a picture:** Share my taste report makes a 1080-pixel-wide picture like the anime.com one (your name and avatar, your archetype, the theme index with covers, your vibe, your four-letter type with its sliders, hidden gems, newer or older picks, genres and biggest rating gaps, and the top lines of *On your list*), then asks **Share image**, **Copy image** or **Save image**. The picture is drawn on your phone (`js/features/taste-card.js` lays it out, `js/features/taste-share.js` draws it) and is never uploaded. Covers are drawn only if they can be loaded safely; any that cannot show a letter tile. Share and Copy use the native add-on (the cache and Android's FileProvider), Save writes to Pictures > What Next with MediaStore (no permission needed on Android 10 and later). Without the add-on the web view's own share, clipboard and download are tried, and if the picture cannot be shared your report is shared as text.
- **Long lists stay smooth:** Anime and Manga lists draw 24 titles at a time (Show more). Filtering and sorting is now done once per change of list, search, status or filters rather than again on every Show more or redraw, and searching a list of more than 400 titles waits for a pause in typing.
- **Triple Sync security and look** (`js/features/vault.js`, `vault-math.js`, `lock.js`, `lock-math.js`; tested in `tests/unit/vault.test.js`):
  - **Encrypted keys:** in the Android app (with the Kotlin add-on) the client IDs, client secrets, login tokens (AniList target, MyAnimeList) and the three Discord webhook links are kept in the phone's encrypted store (the same one that holds your AniList login), not in normal storage. Older plain copies are moved over at the first start and removed once the encrypted copy reads back correctly. If the encrypted store does not work, everything keeps working from normal storage and the page says so (*Encrypted* or *Not encrypted* pill; the bug report says *Triple Sync keys: encrypted or normal storage*).
  - **Never shown again:** a saved key is not put back in the form. The field shows *Saved · ••••abc* (a webhook shows only its last 4 characters); typing replaces it, and *Remove saved value* (tap twice) deletes it. Logs, the bug report and Discord error messages have webhook links, bearer tokens and key values replaced with [hidden]. Thread ids for forum channels used to be stored under the webhook link itself; they are now stored under a short fingerprint of it.
  - **PIN lock:** **Security > Lock this page with a PIN** (4 to 8 digits, no all-the-same or running digits) asks for the PIN before the Triple Sync page opens, and optionally before **Import Lists** in Account Settings. Only a salted PBKDF2 hash (150,000 rounds) of the PIN is saved. Four wrong tries are free, then the lock waits 30 s, 1 min, 5 min, 15 min and 1 hour. It asks again every time you open the page, or after 1, 5 or 15 minutes away (also when the app comes back from the background). With the add-on it can also use your fingerprint, face or phone screen lock, and it can hide the page from screenshots and the recent-apps view. **Forgot the PIN** erases the Triple Sync keys, links, memory and the lock so you can start again. The lock protects who can see and change the keys; automatic syncing keeps running while the page is locked. Signing out removes the encrypted keys and the lock too.
  - **New look:** a strip at the top shows where your list goes (Source, the two accounts, Discord) and which ones are connected; sections are numbered 1 to 5 with a status pill each; the Security card sits above the settings.
- **Mark as done:** save your progress to AniList straight from a pick. It marks a title Completed when you finish it, and moves a Planning title to Current.
- **Blur covers:** hides cover art when you're in public.
- **Safe retries:** every AniList request goes through one place (`gql` in `js/core/auth.js`) that keeps to the request limit, waits when AniList says "too many requests", and retries a failed request at most twice. A change that may already have gone through (follow, favourite, chat message, deleting a custom list) is never sent a second time after a server error, because a toggle would flip back and a message would be posted twice; list edits and settings give the same result when repeated, so those are retried. After "too many requests" any request is retried, since AniList did not process it.
- **Login safety:** the login link `whatnext://auth` is only accepted within 10 minutes of tapping Log in, once, and (when AniList sends it back) with the same `state` value that was sent. Links that open from AniList data must be web pages (`https://`). Every build runs `tests/unit/secrets.test.js`, which stops the build if a key, token, private key or webhook secret is found in any file. The workflows keep the signing key out of the repository (it lives in GitHub Secrets), and `dependabot.yml` (uploaded by hand to `.github/`) asks GitHub for weekly update pull requests for the build tools.
- **Packages added for notifications:** `@capacitor/local-notifications` in `package.json` (settings in `capacitor.config.json`: the small icon). If `package-lock.json` does not list it yet, the build runs `npm install` instead of `npm ci` and says so; run `npm install` once on a computer and upload the new `package-lock.json` to get fixed versions again.
- **Native add-on (Kotlin):** `native/kotlin/WnSecurePlugin.kt` is a small Capacitor plugin, **WnSecure**, that keeps the AniList login token in Android's encrypted storage (Keystore) instead of `localStorage`. The build adds it with `python3 native/apply-addon.py android`, which checks everything first and changes nothing if a check fails. It is optional: if adding it or the Gradle build fails, the workflow builds again without it and the release text says "Native add-on (secure login storage): no". The app finds the plugin at start (`secureStore()` in `js/core/auth.js`), moves an old plain-text token over (deleting it only after it reads back correctly) and falls back to `localStorage` if the secure store ever fails, so it can never log anyone out. The bug report shows "Secure login storage: on/off". See `native/README.md`.
- **Code checks:** `tools/tsc-gate.js` runs the TypeScript checker over the JavaScript (it only reads; `tsconfig.json`, `types/globals.d.ts`) and fails the test workflow on a missing name, a repeated const/let or a call to something that is not a function. `eslint.config.js` lists mistakes for ESLint (repeated names, unreachable code, a const that is assigned again and so on); that step is report-only for now (`continue-on-error`), so read its list before making it strict. Both run in `.github/workflows/tests.yml`, not in the release build.
- **Bug report details:** the report copied from About includes the last 30 steps (screens opened, and for each AniList request only its operation name and the status number), plus the recent errors. It never contains your token, request details or list contents.
- **Lighter pictures:** list rows in the Linear layout and the other small thumbnails use the medium AniList cover (about a quarter of the download, with a fall-back to the large one), Pick and Trending use the large cover, and only the title page asks for the extra large one.
- **Anime and Manga lists:** your full AniList lists with status tabs, search, a filter sheet (sort, format, status, country, year, length, score, genres include/exclude) and list customisation (below). Tap a card to open the title; **long press** a card for a quick view with -1 / +1 progress, score, priority and the start of your note. If you use custom lists on AniList, a **Custom lists** button next to Search, Filter, and Customise opens a sheet with each list and how many titles it holds; pick one to see only its titles (it combines with the status tabs and search).
- **Customise list** (Customise button on the Anime and Manga screens; saved on the phone, applies to both lists):
  - **List type:** *Linear* (cover and details in a row), *Grid* (2, 3 or 4 columns), *Simplified* (text only, one slim row per title, no covers downloaded) or *Album* (big covers with the title and progress on the picture; same column choice as Grid).
  - **Experience:** long press to quick view (on by default), hide score when not scored, hide progress, hide airing indicator, show Notes indicator (a small *Note* tag on titles that have a note) and show Priority indicator (*Low*, *Medium* or *High*, from the priority you set in the list editor).
  - **Background image:** pick a picture from the phone to show, dimmed, behind the Anime and Manga lists; **Remove** puts the normal background back. The picture is shrunk to at most 1600 px and kept on the phone. It is removed when you sign out. **Reset to default** at the bottom puts every list option back and removes the picture. **Hide airing indicator** also applies to Linear (Simplified shows the airing text in its status line). The quick view also has status chips to move a title between Watching/Reading, Planning, Completed and so on.
- **Swipe down to refresh:** pull down at the top of Pick, Anime, Manga, Discover, Seasonal, Calendar, Schedule, Stats, Taste report, or Profile to reload that screen from AniList.
- **Trending:** trending anime and manga carousels on the Pick screen.
- **Media pages:** tap any title for a full page with score, favourites, genres, synopsis, characters, info, tags with spoiler toggle, where to watch, staff, relations, and recommendations. Relations and recommendations open their own pages.
- **Character, staff, and studio pages:** tap a character, staff member, studio, or producer on a media page to open its own page, with Set as Favorite, voice actors, series or media, roles, and See more. Tapping a title inside those pages opens it, and the back button walks back through every page.
- **List editor:** status, progress stepper, score slider, start and finish dates, rewatches, priority, custom lists, notes, private, favourite, and remove. Reaching the last episode completes the entry and sets dates automatically.
- **People:** on your Profile, tap Following or Followers for the list (a Mutual badge marks people who follow you back; the three-dot menu can follow, unfollow, or open AniList). Tap anyone to open their profile: banner, avatar, counts, an affinity score from the scores you both gave to the same titles (needs 5 or more shared scores), their statistics, View Detail Statistics with the same charts as yours, Follow, and Message. Tap their **Anime** or **Manga** count to read their list (read-only): status chips with counts, a search box, Updated / Score / Title sorting, 24 titles at a time with **Show more**, and the same layout you chose in Customise list. Tap a title to open its page, and Back returns to their list. A private list shows "This person keeps their list private." On your own profile the same counts take you to your Anime and Manga tabs.
- **Profile:** your AniList banner and avatar (ring uses your AniList profile colour), a View on AniList button, anime, manga, following and followers counts, your anime and manga statistics, and your bio, with Stats, Chat, and Settings as tiles at the very bottom, under Tendencies. The banner and avatar are read from AniList; the AniList API does not let apps change them. It also has **Tendencies** (Anime or Manga, worked out from your AniList stats: top-genre bars with your share and average score; under Taste: what you seem to love and hate, your highest-rated genre, tags, format mix, favourite era, studios or origins; under Habits: time spent, busiest year, first year recorded, completion and drop rate, Planning backlog; the extra statistics are optional, so if AniList refuses them the basic ones still show) and **Favourites** with filters for Anime, Manga, Characters, Staff, and Studios (12 at a time to save requests; tap one to open it; Show more loads the next 12). Tendencies and Favourites are saved for 14 days, shown at once, and refreshed quietly after 6 hours or when you pull down.
- **Settings:** App Settings, AniList Triple Sync (only when Advanced features are on), account, and three pages that follow the AniList apps:
  - **App Settings** (this app only): a theme picker with 26 anime themes in groups: **One Piece** (One Piece, the default, plus Sanji, Nami, Robin, Zoro, Luffy, Usopp and Wano), **Isekai** (KonoSuba, Shield Hero, Magical Explorer), **Fantasy** (Black Clover, Sword Art Online, Mashle), **Action** (Naruto, Dragon Ball, Bleach, Attack on Titan), **Comedy** (Gintama), **Rom Com** (Rent-a-Girlfriend), **Romance** (Sakura Flowers), **Magical Girl** (Sailor Moon), **Mystery** (Detective Conan), **Movies** (Your Name, Suzume) and **Hentai 18+** (Ikenie no Haha: colours and patterns only, and the group stays hidden until **Show 18+ themes** is switched on). Several themes have a faint pattern behind the app (petals, Edo waves, stars, scales, magic circles, clovers, hexagons, lightning, embers, a comet, doors, moons, magnifying glasses, slashes, smoke, tangerines, blossoms, pellets, hemp-leaf lines, straw weave). Every theme is checked for readable text by `tests/unit/themes.test.js`. To add a theme, add one entry to `THEMES` in `js/core/theme.js` (and a group to `THEME_GROUPS` if it needs one); round or square profile pictures; text size; the opening logo screen; where "All" sits in the status chips; relative or exact air times; how titles from Japan, Korea, China and Taiwan are shown (Follow AniList, Romaji, English, Native); privacy (blur covers, hidden titles); and a reset.
  - **AniList Settings** (saved on your account, with a Save Changes bar): bio, profile colour, title language, staff and character naming, activity merge time, 18+ content, airing notifications, and only getting messages from people you follow.
  - **Account Settings:** who you are signed in as, buttons that open the right AniList pages (profile, account, import, app access, delete account), waiting changes, clearing saved lists and pictures, copying app info, and **Log out** (tap twice to confirm).
- **Login screen:** the logo over a soft animated background, what the app does, Log in or Create account, and a note that you log in on anilist.co and the app never sees your password.
- **AniList Triple Sync (advanced):** copies your list (the source: the account you are logged in with, or any AniList username) to a **second AniList account** and to **MyAnimeList**, for anime and manga, with an optional **Discord report**. It is locked: it only appears in Settings, and only runs, when **App Settings > Advanced features** is switched on.
  - **Settings, all on its own page and saved as you change them:** the source username; the target AniList client ID and secret; the MyAnimeList client ID, secret and redirect URL; the three Discord webhook links and the lists that get their own thread; and the options (send to AniList, send to MyAnimeList, protect the targets, add missing titles, remove titles, skip 18+ titles on MyAnimeList, auto-sync and how often: 1, 3, 6, 12 or 24 hours). Secrets, tokens and the webhook link stay on this device.
  - **You bring your own keys.** For the target AniList account, make an API client at anilist.co/settings/developer with the Redirect URL `https://anilist.co/api/v2/oauth/pin`, type its client ID and secret, log in with the account to copy to, and paste the code AniList shows. For MyAnimeList, make an API app at myanimelist.net/apiconfig, type its client ID (and secret if it has one) and the same redirect URL, log in, and paste the link or code you are sent back with. The app uses native requests (see `CapacitorHttp` in `capacitor.config.json`), because MyAnimeList refuses requests that come from a web page.
  - **What is sent:** status, progress, volumes, score, rewatch counts, start and finish dates, notes and privacy (AniList), or the matching MyAnimeList fields. Titles need a MyAnimeList ID to go to MyAnimeList.
  - **Protect the targets (on by default):** each title is read on the target first. A title that is further along there (completed, or more progress) is left alone, an update never lowers progress or clears a score, notes, dates or rewatch count, and identical entries are not written again. This costs one extra request per title. Switch it off to let the source simply win.
  - **Starting:** the first run to each target asks how to start: copy the whole list, or only send changes from now on. The memory belongs to the accounts: connecting a different target account asks again for that target only, and changing the source clears the memory, so nothing is wrongly treated as removed. **Preview** says what would be sent without sending anything, and **Sync both** does anime then manga.
  - **After that** only changed titles are sent (a fingerprint of each title is remembered per target, including partial dates). A title a service rejects (for example an episode count it won't accept) is listed under **Problems** with the reason and is not retried until it changes, or until you tap "Try the rejected ones again". A temporary failure is retried next time. Titles removed from the source are deleted from the targets only if you tick that option; they stay remembered until the delete works, and if 11 or more (over a quarter of the list) vanish at once nothing is deleted and you are asked to remove or keep them. Auto-sync never starts a first copy and does not count a stopped run as done.
  - **Discord, three optional webhooks** (made in Discord: channel settings > Integrations > Webhooks):
    - **Log report webhook:** after each sync a short summary (counts, problems, optionally the titles). A quiet option skips runs where nothing happened, and a button sends a test report.
    - **Anime webhook and manga webhook (update cards):** one card for each title whose progress goes up, like the cards of the Python engines: the title as "UPDATE: …", Romaji, Status, Progress, Left (episodes or chapters), the cover's colour as the side bar, and the poster; a finished series is marked "SERIES COMPLETED". Cards are sorted into forum threads named like `[ANIME] Iseki`: a title goes to the thread of its first custom list if that list is named in **Lists that get their own thread** (the setting starts with your usual ones), or to a guess from its tags and format (movie, isekai, hentai, milf, loli), otherwise to `[ANIME] General Updates` (or `[MANGA] …`). Each thread is made once and remembered; if it is deleted a new one is made; a plain channel that is not a forum just gets the cards. Test buttons send a sample card.
    - **How cards behave:** the first sync only remembers your progress and posts nothing, a title new to the list or whose progress went down is remembered quietly, there are at most 50 cards per run (the rest are mentioned in the log), and cards work even with no target account connected. If Discord refuses a webhook (deleted, wrong link, no permission) or has a problem of its own (a 5xx error) the run stops posting cards at once, says what Discord replied and what to do, and keeps the cards for the next sync; a single card Discord won't accept is reported with its title and Discord's reason, and is not repeated. The test buttons first check that the webhook exists and say which thread the card went to. A forum channel works for the log report too (each report starts a thread).
    - The old Discord Sync page's webhook and source are carried over once, and its other stored data is deleted.
  - **Pace and limits:** sending is paced for AniList (about 90 requests a minute per network address, shared with the rest of the app) and slows down when AniList says the limit is close (in the Android app; browsers may hide those headers). There is a Stop button, and the screen is kept awake during a run because Android may pause a background app. 18+ titles can be kept off MyAnimeList; if MyAnimeList refuses a title it is reported as rejected (possibly age-restricted).
  - It is the same logic as the AniList to MyAnimeList delta engines in the Anilist-triple-sync repository (`mal_sync_engine.py`, `mal_manga_sync_engine.py`) and its AniList write-back, moved into the app. Custom lists are not synced.
- **Notifications:**
  - **Release reminders (phone notifications):** for every anime on your list (Watching, Rewatching, Planning) that airs in the next two weeks, you get up to three notifications per episode: **3 hours before**, **30 minutes before** and **when it airs**. Each can be switched off in Settings > Notifications. A reminder whose time has already passed is skipped (an episode that airs in 2 hours gets the last two). Titles with a release date but no airing schedule yet (anime that start soon, manga) get one reminder at 9:00 on the release day. AniList has no chapter dates, so manga has only that one. Tapping a reminder opens the title page.
  - **How it works:** the app plans the reminders with the official Capacitor Local Notifications plugin (Android alarms), so they arrive with the app closed and survive a restart. It plans again whenever the app opens, your list changes, or air times move (at most every 3 hours unless something changed), always replacing the old plan, so a delayed episode never leaves a stale reminder. At most 400 are scheduled at once (Android allows about 500 alarms), earliest first. The notification numbers are worked out from the title and episode (`nfId` in `js/features/notify-math.js`), so planning twice never doubles a reminder. The pure maths is tested in `tests/unit/notify.test.js`.
  - **Permission:** Android 13 and later asks once to allow notifications. **Settings > Notifications** shows the state, has an **Allow notifications** button and a **Send a test notification** button. The build adds `POST_NOTIFICATIONS`, `RECEIVE_BOOT_COMPLETED`, and the exact-alarm permissions (`USE_EXACT_ALARM`, granted automatically on Android 13+; `SCHEDULE_EXACT_ALARM` below that) so reminders arrive on the minute. Some phones stop apps in the background to save battery: set What Next? to unrestricted battery use if reminders come late.
  - **Notifications screen (the bell):** your AniList notifications as cards (cover, time, sentence), like the AniList apps: *Episode 6 of … aired.*, *… was recently added to the site.* (a sequel added), *… was recently edited.* with the reason (for example a status change), and activity from other people (*… liked your activity.* with **View Detail**, replies, mentions, messages, follows, forum). Chips filter **All / Airing / Your titles / Activity**; **Show more** loads older ones; pull down or tap the refresh button to reload. Opening the first page marks them read on AniList, as AniList's own site does, and the bell shows AniList's unread count. New ones are outlined. The words come from AniList. What AniList notifies you about is still chosen in Settings > AniList Settings.
  - **Alerts while the app is closed (sequel added, title changed):** AniList has no push service, so the optional Kotlin add-on (`WnNotify`, see `native/README.md`) checks AniList every 30 minutes in the background and shows a phone notification for each new one. They can arrive up to about half an hour late, and only when the build includes the add-on (the release text says `yes`; the bug report says *Background alerts: on*). Airing alerts are not repeated here, because release reminders already cover them. Activity (likes, replies, follows) is off until you switch it on.
- **Schedule:** every airing anime on your list, grouped by day with a title, episode, air time or countdown (App Settings decides which), how many episodes are waiting for you and how far you are through the aired ones. A day strip at the top jumps to one day (with a count for each), and All / Watching / Planning narrows the list. A green tag means the episode is already out; a ringed tag means it airs within 3 hours.
- **Stats:** two tabs. **Overview** shows your AniList statistics with anime and manga side by side (totals, genres, status, demographics, formats, tags, score spread). **Progress** shows today's goal ring and streak, a last 7 days chart, a Continue list with +1 buttons, and your backlog. The daily count includes episodes and chapters you update on AniList or other apps, read from your AniList activity (if you turned off list activity on AniList, only this app's updates count).
- **List Settings:** the same options as AniList's list settings page, saved to your account with Save Changes: scoring system and advanced scoring, default list order, split Completed by format, which list activity to stop creating, custom anime and manga lists (add or remove), and the section order (Start Reorder uses the up and down buttons). Removing a custom list also removes it from every title that uses it.
- **Relation map:** on a title's page, Relations > Relation map draws the whole franchise as a graph (source above, prequels above, sequels and side stories below). Toggle Core, Related, and Character links, zoom with the buttons or two fingers, tap a label or use Branches to fold a branch, switch to List view, and add titles to Planning straight from the map. Big franchises stop at about 90 titles (140 with Character links), and a **Load more titles** button adds 60 more each time.
  - **Draws while it loads:** the map appears after the first batch and fills in as more titles arrive (the status says how many so far), instead of staying blank until everything is loaded. It stays centred on your title until you touch the map. If a later batch fails, what loaded is kept.
  - **Watch order / Read order** (next to List view): the franchise in release order, numbered, with each title's link to this one, your status and progress, and a bar of how much of the main story you have finished. The **main story** is the prequel and sequel chain (marked with a blue edge); side stories and the rest are listed in between by date. One title is marked **Start here** or **Next up**: the first released main-story title you have not finished or dropped (unreleased seasons are shown as *Not out yet*, never as next). Titles of the other kind (the manga source of an anime, or the anime of a manga) are listed apart. The choice of view is remembered (`js/features/relmap-order.js`, tested in `tests/unit/relmap.test.js`).
  - **Richer cards:** progress next to your status (*Watching 5/12*), and a small *Airing*, *Soon*, *Hiatus* or *Cancelled* note. Prequel and sequel lines are drawn thicker than the rest.
- **Offline:** shows your last saved list and Pick when you have no connection, and keeps your changes until you are back online.
- **Chat:** one-to-one private messages with other AniList users, using AniList's own message system.
- **Login required:** you must log in with your AniList account. There is no guest mode.

## How picks work

- Anime episodes use the show's real episode length (24 minutes if AniList doesn't list one).
- Manga chapters are estimated at 6 minutes each. Change `MIN_PER_CHAPTER` in `js/core/core.js` if that doesn't suit you.
- Airing shows only offer episodes that have already aired.
- Titles you're already in the middle of are favoured over Planning ones, and higher-rated titles are favoured a little. There's some randomness, so **Show me another** gives you different picks.

## Setup

### 1. Build the app
Push the files to your GitHub repo (from a phone, see *Getting the files into your repo from a phone* below). The **Build APK** workflow first runs the quick tests (an APK is only built if they pass), then builds the app and publishes it as a new release. The first build saves `package-lock.json`, and every later build uses those exact dependency versions.

### 2. AniList login (one time, for the developer)
Login works like other AniList apps: the Client ID is built in, so people just tap **Login**, AniList opens in the browser, and they come back to the app signed in. Create a client at [anilist.co/settings/developer](https://anilist.co/settings/developer) with the Redirect URL `whatnext://auth`, and put its Client ID in `config.js` (`clientApp`). Client IDs are public, not secrets. Without `config.js` the app uses a built-in default.

### 3. Log in
Tap **Log in with AniList** and approve. The browser returns you to the app signed in.

## Staying under AniList's request limit

AniList limits how many requests an app may send per minute (its docs say 90, and 30 while the API is degraded) and answers "too many requests" with a one-minute timeout. `js/core/pacer.js` reads the real limit from AniList's answers and spaces requests so the limit is not hit. Reading screens keep a few requests in reserve, so saving your change never waits behind a big load. If AniList does say "slow down", everything waits for the time it asks for, and a clear message shows when the wait would be long.

## Screens (v3 look)

- **Lists (Anime, Manga):** 24 titles are drawn at a time (**Show more** adds 24). The toolbar (Search, Filter, Customise, Custom lists) is four equal tiles with icons, the status row stays at the top while you scroll and shows a colour dot and count per status, and each card has a gradient **+1**, a status badge, the score, progress, and for airing anime a badge: **"3 new"** when episodes are out that you have not watched, otherwise **"Ep 8 · 2d"** until the next one airs.
- **Pick:** a clear order: filters, the big **Pick for me**, then **Surprise me** and **Build a lineup**, then **Something new for my taste**. The result card shows score, format and genres as chips and an **Up next** tile (what to watch or read, time, and where you are, with a progress bar).
- **Title page:** a title's banner is shown sharp across the top with a fade into the page (a title without a banner shows its cover, blurred).
- **List editor:** a cover header, then card sections (Status, Progress with an **All** button, Score, Dates, Rewatches, Priority as one connected control, Private as a switch, Custom lists, Notes) and the Remove / Save bar.

## Discord card themes

Update cards for lists that have their own thread can have their own look (`TS_THEMES` in `js/features/triple-math.js`). Themes so far (the list name only has to contain the word):

| Theme | List names | Look |
|---|---|---|
| Isekai | Isekai, Iseki, Tensei | violet, gem bar, quest wording |
| Rom Com | Rom Com, Romantic Comedy | pink, heart bar, love-story wording |
| Hentai (18+) | Hentai | crimson, plain "after dark" wording |
| Mature (18+) | Milf | rose, plain "mature shelf" wording |
| Anime Movies | Anime Movies, Movie | amber, cinema wording, "Part" instead of Episode |
| Fantasy | Fantasy | green, dragon and quest wording |
| Favourite | Fav, Favourite, Favorite | gold, hall-of-fame wording |
| Plan to Continue | Plan to continue | teal, "pick up where you left off" |
| Planning | Planning | blue, watchlist / reading list wording |

If a list name fits two themes, the one higher in this table wins. Lists without a theme (for example any list not named above) keep the standard card. Add the list name to "Lists that get their own thread" too, or its titles go to General Updates. The border colour follows the poster (AniList gives each poster's main colour; it is adjusted so it always shows well on Discord's dark background, and a grey or black-and-white poster keeps the theme colour). Turn it off with **Border follows the poster's colour**. Turn themes off with **Themed cards** under Settings > Triple Sync > Discord; the **Look used by the test buttons** select previews a look in General Updates without touching your list threads. To add a theme, add an entry to `TS_THEMES` with the list names it matches.

## About screen

Settings > About shows the version (read from the installed app), **Check for updates** (asks GitHub for the latest stable release and opens it when it is newer than the installed build; otherwise it says "No new updates available"), **What's new** (the release notes), **Open source licenses**, **Privacy policy** (`PRIVACY.md`) and link icons. The icons for website, Discord, X, Facebook and Reddit only appear when their address is filled in under `links` in `config.js`. Releases are named `v<version>-b<build>` by the build workflow, and the update check relies on that.

## Saved data and automatic sign-out

The app keeps copies of what it loads so screens open at once and still work offline. Every saved item has a timestamp and is deleted by itself when it is too old (`js/core/cache.js`):

| Kind | Kept for | What it is |
|---|---|---|
| Cards | 3 days | anime and manga pages, character/staff/studio pages, trending, the seasonal chart, the taste sample, tag list |
| Calendar | 7 days | the airing schedule |
| Account | 14 days | your lists, your Pick pool, your profile, your statistics, your activity days |

Old items are swept when the app opens, when you come back to it, and every hour. Saved pages are shown first and refreshed quietly (your list status and scores can change). Changes that are waiting to sync, your settings and your daily goal are never cleared by the cache. **Settings > Account > Clear saved lists and pictures** clears the cache by hand.

Saved data is never trusted blindly: each kind is checked for the shape its screen needs when it is read (`CACHE_OK` in `js/core/cache.js`). A damaged item, or one written by an older version, is deleted and loaded again instead of crashing the app. If you change what a screen saves, update its check. The calendar is saved **week by week**: a week that is over is never asked for again, this week and next are refreshed after 10 minutes, and other weeks after an hour, so opening the calendar costs a few requests at most.

**14 days unused = signed out.** The app remembers when it was last used. If that was more than 14 days ago, it tries once to send any changes that were waiting, signs you out, and removes your saved data from the phone; you log in again. Logging out by hand removes the same things (the login, saved data, waiting changes, Triple Sync keys and chats). If a different AniList account logs in on the same phone, the old account's data is removed first.

## Logo and splash screen

The logo is `assets/logo-512.png` (and smaller copies). When the app opens it shows an opening screen for at least a second: a deep purple glow, the logo, the name "What Next?", a short tagline, a loading bar that fills as the app's files load, and a footer line (see `#boot` in `index.html`, the `#boot` styles in `css/base.css`, and `SPLASH_MS` in `boot.js`; the screen can be switched off in App Settings). The logo is also shown in the header, and on the login screen. The Android launcher icon and native splash are generated during the APK build from the pictures in `resources/` (step "Generate app icon and splash screen" in `.github/workflows/build-apk.yml`).

## Builds and releases

Every build of `.github/workflows/build-apk.yml` creates its own GitHub release (tag `v<app version>-b<build number>`, for example `v2.1.1-b14`) with the APK attached, so the newest build is always the newest release.

**Why a new APK installs over the old one (and what to do when it says "conflict").** Android only updates an app when the new APK has the same signing key and a higher version code. The build makes sure of both, and keeps the key secret:

- **Same key every time, kept in GitHub Secrets, never in the repo.** This repo is public, so a key stored in it (or protected by a well-known password such as `android`) would let anyone sign an APK that Android accepts as an update to this app. The key therefore lives in two repository secrets: `ANDROID_KEYSTORE_BASE64` (the key file as one line of base64) and `ANDROID_KEYSTORE_PASSWORD`. `android-signing/patch-android.sh` decodes the key during the build, checks that it opens and is the key this repo expects, and sets it as the signing config in `build.gradle` reading the password from the environment, so the password is never written to a file. `android-signing/fingerprint.txt` holds the key's SHA-256, which is public and is not a secret. `.gitignore` and a test keep key files from ever being committed again.
- **Version code that only goes up.** It is the number of minutes since 2023-11-14, taken from the clock, so it keeps rising even if the workflow's run counter is ever reset (a lower version code is treated as a downgrade and refused).
- **A release build, with a debug build as a fallback.** The workflow builds a signed release APK (not debuggable, so other tools cannot read the app's stored data from a connected phone). If the release build fails for any reason it builds a debug APK instead and shows a warning, so a build is never lost.
- **Checked before it is released.** `android-signing/verify-apk.sh` reads the finished APK with `apksigner` and `aapt2` and fails the build if its signing key is not the one in `fingerprint.txt` or its version is not the one meant. The build log prints `Signing certificate SHA-256: ...`, and every release says which key and version code it has, so two builds can be compared at a glance.

To set the secrets up (once): in the repo open **Settings > Secrets and variables > Actions > New repository secret**, add `ANDROID_KEYSTORE_PASSWORD` and `ANDROID_KEYSTORE_BASE64`, and make sure `android-signing/fingerprint.txt` matches the key. To make a new key yourself instead, run `bash android-signing/generate-key.sh` on any computer with Java: it prints both secret values and the fingerprint, and saves nothing in the repo. Keep a private backup of the key file outside GitHub: without it the next APK cannot update the installed one.

If you change the key, or an app on your phone was installed from a build signed with a different key, uninstall it once; after that every build installs over the previous one and keeps your data. The `latest-apk` release from earlier builds is not used any more and can be deleted.

When you upload `site.zip`, only the unpack workflow runs at first; it then starts the APK build, so one upload makes one release.

## Privacy

- Everything runs in your browser. There is no server and no analytics.
- Your login token and Client ID are stored in your browser's local storage on your own device, and are only sent to AniList.
- Log out to clear the saved token.
- The login wall is part of the page, so it controls what the app shows but isn't strong security by itself. Your private data stays protected by AniList and your account's token.

## Notes

- This is an unofficial app and isn't affiliated with AniList.
- 18+ features are for adults only. Content shown is whatever AniList lists as adult, and your AniList account settings apply.
- Discover only links to AniList pages. It doesn't link to streaming or reading sites.

## Built with

Plain HTML, CSS, and JavaScript, using the [AniList GraphQL API](https://docs.anilist.co/).

## Project structure (where to edit)

The app is split into folders, so one problem area can be fixed without touching the rest.

```
index.html              thin shell: splash, #screens, #overlays
boot.js                 loads the views and scripts in order; holds REV
config.js               AniList client ID
capacitor.config.json   Android app settings (Capacitor)
package.json            Capacitor plugins and the app version
assets/                 logo, app icons and the splash-screen image
resources/              Android icon and splash sources (used only by the APK build)
android-signing/        the key's public fingerprint and the scripts that sign, check and make the key (the key itself is in GitHub Secrets)
css/                    base, components, screens, login, trending, media, anistats, refresh, profile, themes, triple,
                        listset, relmap, users, progress, discover, taste, utilities
views/
  shell/                header, tab bar
  screens/              login, pick, discover, seasonal, taste, calendar, chat, schedule,
                        stats, lists, profile
  settings/             menu, app, anilist, lists, sync (AniList Triple Sync), account, about
  sheets/               filter, customise, overlays (media page and editor), relmap, user
js/
  core/                 compat, cache (smart cache and session clock), pacer (request limit), markup (text and spoilers), diagnostics, core and Pick engine,
                        tabs, auth, tracker, session (sign-out and wipe), theme, start
  features/             discover, seasonal, taste (screen), taste-math (the maths), pick-taste (new picks), refresh (swipe down), profile-extra (tendencies, favourites), calendar, lists, media page, entity pages
                        (character/staff/studio), editor, relation map, users, profile,
                        stats, list settings, app settings, settings, sync (AniList Triple Sync) and triple-math (its maths),
                        chat, trending, and so on
tests/                  structure check, unit tests, and real-browser screen tests
.github/workflows/      tests.yml, unpack-site.yml, build-apk.yml
```

If you add a new screen or script file, add it to the lists inside `boot.js`.

**Releasing a change:** whenever any file changes, change `REV` in `boot.js` (for example `3.0.0-r2`). That makes every phone load the new files together instead of mixing old and new ones.

## Tracking (one place for every change)

Every change to a list entry goes through `js/core/tracker.js`: the +1 buttons on the lists, the media page, Pick's "Mark as done", the list editor, and adding to Planning.

- Status and dates follow the same rules everywhere: +1 on a Planning, Paused, or Dropped title starts it and fills the start date; reaching the last episode completes it and fills the finish date; finishing a rewatch completes it and adds one rewatch; lowering a completed title reopens it; starting a rewatch resets progress to 0.
- The screen updates instantly. AniList is updated right after, one request per title at a time, and a failed save is rolled back with a message.
- With no connection the change is kept on the device and sent when you are back online.
- Scores follow your AniList score format (100 point, 10 point decimal, 10 point, 5 star, or smiley).

## Tests

```
node tests/check-structure.js        files, lists, ids, CSS, versions
node tests/unit/rules.test.js        tracking rules and score formats
node tests/unit/taste.test.js        taste report maths
node tests/unit/triple.test.js       AniList Triple Sync maths
node tests/unit/apk-signing.test.js  APK signing scripts, the workflow's release build, and that no key file is committed
python tests/e2e/run_all.py          real-browser tests against a fake AniList (needs: pip install playwright && playwright install chromium)
```

The `Tests` workflow (`.github/workflows/tests.yml`) runs the structure check, `rules.test.js` and the browser tests on every push; the other unit tests can be added to it by hand.


## Getting the files into your repo from a phone

GitHub's phone upload can't take folders. Upload the single file `site.zip` to the repo root instead. The `Unpack site.zip` workflow (`.github/workflows/unpack-site.yml`) unzips it into the folders above, deletes the zip, and commits. In the APK repo it also starts the APK build.

## Credits

- Company: Tokyo Brotherhood
- Creator: Hariharasuthan Karunakaran
- Contributor: Claude (AI)
